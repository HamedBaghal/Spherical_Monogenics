function x = ess(~) %#ok<STOUT>
% Extracts the scalar component of a full quaternion. If q is a pure
% quaternion, an error is raised, since the scalar part of a pure
% quaternion should not be extracted.

% Copyright © 2005 Stephen J. Sangwine and Nicolas Le Bihan.
% See the file : Copyright.m for further details.

error('Obsolete private function ess called.')

end

% $Id: ess.m 1113 2021-02-01 18:41:09Z sangwine $
