function F = funm(~,~) %#ok<STOUT>
% Evaluate general matrix function.
% (Quaternion overloading of standard Matlab function.)
% This function is not yet implemented for quaternions but may be
% added at a later date. Please contact the authors of QTFM.

% Copyright © 2008 Stephen J. Sangwine and Nicolas Le Bihan.
% See the file : Copyright.m for further details.

help quaternion/funm;
unimplemented(mfilename);

% TODO Implement the function funm.

end

% $Id: funm.m 1113 2021-02-01 18:41:09Z sangwine $
